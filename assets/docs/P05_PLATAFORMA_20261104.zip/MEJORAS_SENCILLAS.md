# Mejoras sencillas propuestas — P05

Propuestas para el detalle de fabricación y la operación, conservando el diseño actual.

- **Señalización:** identificar la carga prevista y el recorrido de izaje, y colocar una secuencia breve junto a la botonera fija.
- **Rejilla desmontable:** utilizar clips estándar de fijación para permitir limpieza y retiro controlado de los paños.
- **Cambio de nivel visible:** aplicar contraste antideslizante en el borde del escalón de conexión con la pasarela.
- **Inspección rutinaria:** revisar estado y limpieza de manga, sello y filtro, y comprobar las asas del BigBag antes del enganche.

Estas propuestas no se presentan como modificaciones ya fabricadas. Las comprobaciones digitales de esta entrega verifican geometría y recorridos nominales; no constituyen validación estructural ni certificación del equipo.
